<div class="container">
  <div class="row">
    <div class="col-sm-12">   
      <div class="wizard-container"> 
          <div class="card wizard-card ct-navbar-blue" id="wizardProfile col-sm-4">
            
              <div class="wizard-header">
                <h3><b>Data</b> Categori <br>
                    <small></small>
                 
                </h3>
              </div>
              <div class="wizard-footer">
                <div class="pull-right">
                <button type='button' class='btn btn-primary' onclick="add_kursus()" data-toggle="modal"><span class="glyphicon glyphicon-plus" title="Edit"></span>Tambah Kursus</button>
                </div>
                <div class="clearfix"></div>
              </div> 
             
          <div class="col-sm-12 col-md-1">
                            <div class="thumbnail">
                            <div class="caption">
       <p>sdjlasjdlas</p>
      </div>
    </div>
  </div>
        </div>
      </div> <!-- wizard container -->
    </div>
</div><!-- end row -->
