
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=site_url()?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
  <div class="container-fluid">
    
   
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-tasks"></i></span>
          <h5>Atur waktu Untuk Pengacakan Soal</h5>
          
        </div>
        <div class="widget-content">
          <div class="row-fluid">
            <div class="span12">
            
             
             <?=$this->session->flashdata('pesan')?> 

         <?=form_open(site_url('latihan/update_time_n_random_per_no'), 'role="form" class="form=horizontal"');?>
                  <input type="hidden" name="latihan_id" value="<?=$latihan_id?>">
       <input type="hidden" name="latihan_title" value="<?=$latihan_title?>">
       <input type="hidden" name="per_count" value="<?=$per_count?>">
             
             <div class="control-group">
             <label class="control-label col-md-3" > lama Ujian</label>
            <div class="controls">
           <?=form_input('duration','','id="timepicker1" placeholder="hh:mm:ss" class="form-control"')?>
                   <label class="control-label col-md-3"> ket : hh = Jam <br> mm: Menit <br> ss: Detik</label>
            </div>
          </div>

           <div class="control-group">
             <label class="control-label col-md-3" > Jumlah Acak Soal</label>
            <div class="controls">
           <?=form_input('random_per','','id="random_per" placeholder="hanya angka" class="form-control"')?>
                   <label class="control-label col-md-12">Jumlah Acak Soal Tidak Boleh Lebih Dari &nbsp; <font color="red"><b><h3><?=$per_count?></h3></b></font></label>
            </div>
          </div>


          
         
         <div class="control-group">
                      <div class="controls">
                        <button type="submit" class="btn btn-primary col-xs-5 col-sm-3">Save</button>
                      </div>
                    </div>
         </form>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <hr>
    
    
    
  </div>
<script type="text/javascript">
  var i=6;
  function add_field()
  {
    var str='<div class="form-group"><label for="section_'+i+'" class="col-sm-offset-0 col-lg-2 col-xs-offset-1 col-xs-3 control-label mobile">section title'+i+':</label>';
    str+='<div class="col-lg-6 col-sm-8 col-xs-7 col-mb">';
    str+='<textarea name="section[]" placeholder="section title'+i+'" class="form-control" row="2"></textarea>';
    str+='</div></div><div id="add_more_field-'+(i+1)+'"></div>';
    document.getElementById('add_more_field-'+i).innerHTML=str;
    i++;
  }
</script>