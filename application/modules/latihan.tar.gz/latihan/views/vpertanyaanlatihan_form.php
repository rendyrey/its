<script type="text/javascript">
//Add basic 4 fields initially
var i = 5, s;
function add_form(val) {
  //  alert(val);
    i = 5;
    var opt = '<div class=control-group><div class="controls">';
        opt += '<p class="text-primary"><i class="glyphicon glyphicon-flash"></i> Input Jawaban</p>';
        opt += '</div></div>';

    for (q = 1; q <= 4; q++) {
        opt += '<div class="control-group">';
        opt += '<label for="Pilihan[' + q + ']" class="control-label col-md-3">Pilihan ' + q + ': </label>';
        
        opt += '<div class="controls">';
        opt += '<span class="input-group-addon">'
        if (val == 'Radio') {
            opt += '<input type="' + val + '" name="jaw" onclick="put_right_jaw(' + q + ')" required="required">  <span class="invisible-on-sm"> Pilihan Benar.</span><br>';
        } 
        opt += '</span>';
        if (q <= 2) {
            opt += '<input name="options[' + q + ']" class="form-control" type="text" required="required">';
        }
        if (q > 2) {
            opt += '<input name="options[' + q + ']" class="form-control" type="text">';
        }
        opt += '</div>';
    }
    opt += '<div id="add_more_field-5"></div>';
    opt += '<div class="control-group">';
    opt += '<label class="col-sm-offset-0 col-lg-2 col-xs-offset-1 col-xs-3 control-label mobile">&nbsp;</label><div class="col-lg-5 col-sm-8 col-xs-7 col-mb">';
  //  opt += '<button type="button" class="btn btn-info" id="add_btn" onclick="add_field()"><icon class="icon-plus"></icon> Tambah Pilihan Jawaban</button>';
    opt += '</div></div>';
    document.getElementById('options').innerHTML = opt;
}

//Add more fields
/* function add_field() {
    var type;
    if (document.getElementById('radio1').checked) {
        type = 'radio';
    } else if (document.getElementById('checkbox1').checked) {
        type = 'checkbox';
    }
    if (i <= 8) {
        var str = '<div class="form-group"><label for="options[' + i + ']" class="col-sm-offset-0 col-lg-2 col-xs-offset-1 col-xs-3 control-label mobil">Option ' + i + ': </label>';
        str += '<div class="col-lg-5 col-sm-8 col-xs-7 col-mb">';
        str += '<div class="input-group">';
        str += '<span class="input-group-addon">';
        if (type === 'radio') {
            str += '<input type="' + type + '" name="jaw" onclick="put_right_jaw(' + i + ')" required="required">  <span class="invisible-on-sm"> Jawaban Benar.</span>';
        } else if (type === 'checkbox') {
            str += '<input type="' + type + '" name="right_jaw[' + i + ']">  <span class="invisible-on-sm"> Correct Ans.</span>';
        }    
        str += '</span>';
        str += '<input name="options[' + i + ']" class="form-control" type="text">';
        str += '</div></div></div><div id="add_more_field-' + (i + 1) + '"></div>';

        document.getElementById('add_more_field-' + i).innerHTML = str;
        i++;
    } else {
        alert('You added maximum number of options!');
    }
} */

//Pick the righ answers and set the value to hidden field
function put_right_jaw(val) {
    var ryt = '<input type="hidden" name="right_jaw[' + val + ']" value="on">';
    document.getElementById('hidden_fields').innerHTML = ryt;
}

</script>


<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=site_url()?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
  <div class="container-fluid">
    
   
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-tasks"></i></span>
          <h5>Data pertanyaan</h5>
          
        </div>
        <div class="widget-content">
          <div class="row-fluid">
            <div class="span12">
            
             
             <?=$this->session->flashdata('pesan')?> 

           <?=form_open_multipart(site_url('latihan/create_pertanyaanlatihan'), 'role="form" class="form=horizontal"');?>
           <div id="hidden_fields"></div>
                <input type="hidden" name="per_no" value="<?=$pertanyaanlatihan_no?>">
       <input type="hidden" name="per_id" value="<?=$title_id?>">
       <input type="hidden" name="latihan_title" value="<?=$latihan_title?>">  
             
             <div class="control-group">
             <label class="control-label col-md-3" > Pertanyaan</label>
            <div class="controls">
             <?php 
                    $data=array(
                        'name'        => 'pertanyaanlatihan',
                        'placeholder' => 'Pertanyaan',
                        'id'          => 'pertanyaanlatihan',
                        'value'       => '',
                        'rows'        => '2',
                        'class'       => 'form-control',
                     
                      );
                   ?>
                   <?=form_textarea($data)?>
            </div>
          </div>
           <div class="control-group" id="media-choose">
             <label class="control-label col-md-3" for="upload-gambar"> Upload Gambar</label>
            <div class="controls">
            	<a href="#" class="btn btn-primary btn-large" id="upload-gambar"></a>
            </div>
            </div>
            <div id="media-option"></div>
          <div id="media-field"></div>
<div class="control-group">
             <label class="control-label col-md-3" for="upload-gambar"> Type Jawaban</label>
            <div class="controls">
             <label class="radio-inline">
            	<input type="radio" id="radio1" name="jaw_type" required="required" value="Radio" onclick="add_form(this.value)"> <span>Tambahkan Jawaban </span>&nbsp;&nbsp;&nbsp;&nbsp;
            	</label>
            </div>
            </div>

            <div class="control-group">
            
            	<div id="options"></div>
            
            </div>

            <div class="control-group">
            <div class="controls">
            	<div id="progressBar" style="display: none;"><br> <img src="<?=base_url('assets/images/loading.gif')?>"></div>
            </div>
            </div>
           

          <div class="control-group">
                      <div class="controls">
                       <button type="submit" onclick="$('#progressBar').show();" class="btn btn-primary"> simpan dan tambah</button>
            <button type="submit" onclick="$('#progressBar').show();" name="done" value="done" class="btn btn-primary"> Simpan dan Selesai</button>
                      </div>
                    </div>
        <?=form_close()?>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <hr>
    
    
    
  </div>
<script type="text/javascript">
$('#upload-gambar').click(function(){
    var type = '<div class="control-group">'
                +'<label for="media_type" class="control-label col-md-3">Media Type: </label>'
                +'<div class="controls">'
                        //+'<input type="radio" value="youtube" name="media_type" required="required" onclick="add_media_field(this.value)"> <span>YouTube </span>&nbsp;&nbsp;&nbsp;&nbsp;'
                       // +'<input type="radio" value="video" name="media_type" required="required" onclick="add_media_field(this.value)"> <span>Video </span>&nbsp;&nbsp;&nbsp;&nbsp;'
                        +'<input type="radio" value="image" name="media_type" required="required" onclick="add_media_field(this.value)"> <span>Image </span>&nbsp;&nbsp;&nbsp;&nbsp;'
                        //+'<input type="radio" value="audio" name="media_type" required="required" onclick="add_media_field(this.value)"> <span>Audio </span>'
                +'</div>'
            +'</div>';
    $('#media-choose').hide();
    $('#media-option').append(type);
})

//Add media fields
function add_media_field(val) {
    var field = '<div class="control-group">'
                +'<label for="media_field" class="control-label col-md-3">Add Media: </label>'
                +'<div class="controls"><input type="hidden" name="media_type" value="'+val+'">';
    if (val == 'video') {
            var types = 'mp4 | webm | ogg';
    }else if (val == 'audio') {
            var types = 'ogg | mp3 | wav';        
    }else if (val == 'image') {
            var types = 'gif | jpg | png';
    };

    switch(val){
        case 'youtube':
            field += '<input type="text" class="form-control" name="media">';
            break;
        case 'video':
        case 'image':
        case 'audio':
            field += '<input type="file" id="media" name="media" style="margin-top:8px;">';
            field += '<p class="help-block"><i class="glyphicon glyphicon-warning-sign"></i> Allowed types = '+ types +'.</p>';
            break;
    }
    field +='</div></div>';

    $('#media-option').hide();
    $('#media-field').append(field);
}
</script>