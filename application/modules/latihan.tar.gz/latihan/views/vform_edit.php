
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?=site_url()?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
  <div class="container-fluid">
    
   
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-tasks"></i></span>
          <h5>Data Latihan</h5>
          
        </div>
        <div class="widget-content">
          <div class="row-fluid">
            <div class="span12">
            
             
             <?=$this->session->flashdata('pesan')?> 

           <?=form_open_multipart(site_url('latihan/update_latihan/'.$latihan->title_id), 'role="form" class="form=horizontal"');?>    
             
             <div class="control-group">
             <label class="control-label col-md-3" > Nama Latihan</label>
            <div class="controls">
            <?php 
                    $data=array(
                        'name'        => 'latihan_title',
                        'placeholder' => 'latihan Title',
                        'id'          => 'latihan_title',
                        'value'       => $latihan->judul_latihan,
                        'rows'        => '2',
                        'class'       => 'form-control',
                     
                      );
                   ?>
                   <?=form_textarea($data)?>
            </div>
          </div>
<?php 
            $kelas=$this->db->get('kelas')->result();
            $option=array();
            foreach($kelas as $kelass){
              $option[$kelass->kelas_id]=$kelass->nama_kelas;
            }
            $sub_kelas=$this->db->get('subkelas')->result();
            $option2=array();
            foreach($sub_kelas as $sub_kelass){
              $option2[$sub_kelass->id]=$sub_kelass->namasubkelas;
            }
          ?>
         <div class="control-group">
         <label class="control-label col-md-3" >Pilih Kelas</label>
         <div class="controls">
            <?=form_dropdown('parent-kelas',$option,$latihan->kelas_id,'id="parent-kelas" class="form-control"')?>
         </div>
         </div>

         <div class="control-group">
         <label class="control-label col-md-3" >Pilih Sub Kelas</label>
         <div class="controls">
           <?=form_dropdown('kelas',$option2,$latihan->id,'id="kelas" class="form-control"')?>
         </div>
         </div>
  <?php 
            $categories=$this->db->get('categori')->result();
            $option=array();
            foreach($categories as $category){
              $option[$category->categori_id]=$category->nama_categori;
            }
            $sub_categories=$this->db->get('subcategori')->result();
            $option2=array();
            foreach($sub_categories as $sub_category){
              $option2[$sub_category->id]=$sub_category->namasubcategori;
            }
          ?>
           <div class="control-group">
         <label class="control-label col-md-3" >Pilih Mata Pelajaran</label>
         <div class="controls">
           <?=form_dropdown('parent-category',$option,$latihan->categori_id,'id="parent-category" class="form-control"')?>
         </div>
         </div>

          <div class="control-group">
         <label class="control-label col-md-3" >Pilih Sub mata Pelajaran</label>
         <div class="controls">
           <?=form_dropdown('category',$option2,$latihan->id,'id="category" class="form-control"')?>
         </div>
         </div>
<div class="control-group">
             <label class="control-label col-md-3" > Silabus</label>
            <div class="controls">
            <?php 
              $data=array(
                  'name'      =>'latihan_syllabus',
                  'id'        =>'syllabus',
                  'placeholder' =>'syllabus',
                  'value'     =>$latihan->syllabus,
                  'rows'      =>'2',
                  'class'     =>'form-control',
                  
                );
             ?>
             <?=form_textarea($data)?>
            </div>
          </div>

           <div class="control-group">
         <label class="control-label col-md-3" >Foto</label>
         <div class="controls">
            <?=form_upload('feature_image','','id="feature_image" class="form-control"')?>
         </div>
         </div>
          <div class="control-group">
         <label class="control-label col-md-3" >Nilai</label>
         <div class="controls">
        <?=form_input('passing_score',$latihan->nilai,'id="passing_score" placeholder="passing_score" class="form-control"')?>
         </div>
         </div>
           <div class="control-group">
         <label class="control-label col-md-3" >Publish Latihan </label>
         <div class="controls">
           <select name="public" class="form-control">
               <option value="1">Yes</option>
               <option value="0">No</option>
             </select>
         </div>
         </div>


          <div class="control-group">
         <label class="control-label col-md-3" >Durasi waktu</label>
         <div class="controls">
          <?=form_input('duration',$latihan->durasi_waktu,'id="timepicker1" placeholder="hh:mm:ss" class="form-control"')?>
         </div>
         </div>

           <div class="control-group">
         <label class="control-label col-md-3" >Acak Soal</label>
         <div class="controls">
           <?=form_input('random_per',$latihan->acak_soal,'id="random_per" placeholder="hanya nomor yang tidak lebih '.$per_count.'" class="form-control"')?>
         </div>
         </div>


          <div class="control-group">
                      <div class="controls">
                        <button type="submit" class="btn btn-primary col-xs-5 col-sm-3">Lanjut</button>
                      </div>
                    </div>
        <?=form_close()?>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <hr>
    
    
    
  </div>
<script>
$('select#parent-category').change(function() {

    var category = $(this).val();
    var link = '<?php echo base_url()?>'+'kursus/getsubcategoriajax/'+category;
    $.ajax({
        data: category,
        url: link
    }).done(function(subcategories) {

        console.log(subcategories);
        $('#category').html(subcategories);
    });
});
$('select#parent-kelas').change(function() {

    var kelas = $(this).val();
    var link = '<?php echo base_url()?>'+'kelas/getsubkelasajax/'+kelas;
    $.ajax({
        data: kelas,
        url: link
    }).done(function(subkelas) {

        console.log(subkelas);
        $('#kelas').html(subkelas);
    });
});
</script>